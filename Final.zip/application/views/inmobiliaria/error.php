
    <div class="text-center">
      <h3>No tiene acceso a esta pagina. Porfavor inicie sesion</h3>
      <a class="btn btn-info" href="<?php echo base_url('/inmobiliaria'); ?>">Continuar</a>
    </div>
