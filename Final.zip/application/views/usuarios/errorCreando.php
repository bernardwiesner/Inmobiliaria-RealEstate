
    <div class="text-center">
      <h3>Error al crear Usuario</h3>
      <?php echo $cond ?>
      <a class="btn btn-info" href="<?php echo base_url('/inmobiliaria'); ?>">Continuar</a>
    </div>
