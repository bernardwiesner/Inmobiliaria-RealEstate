
    <div class="text-center">
      <h3><?php if(isset($mensaje)) echo $mensaje; ?></h3>
      <a class="btn btn-info" href="<?php echo base_url('/inmobiliaria'); ?>">Continuar</a>
    </div>
